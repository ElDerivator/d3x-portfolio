# Changelog — Data & Technology Ticketing System

## v1.0 r3 — A fondo: seguridad, flujos ejecutados y correcciones (2026-11-18)

Validado **0 errores / 0 avisos / 0 linter** + **86/86 pruebas** (52 de app y motor + 34 de flujos) + 11 YAML válidos ·
**327 controles** · 14/14 mutaciones de flujos detectadas.

### Seguridad (corrección de un error de r1/r2)
- r1/r2 recomendaban *Contribute* para toda la empresa sobre las listas de tickets, así que **cualquiera podía leer
  todos los tickets en SharePoint**. Ahora el **Modelo A es el valor por defecto**: `blnRequesterPortal := false`, la
  app es solo para D&T y la empresa escribe al buzón. El nuevo **`Lockdown-DTTicketing.ps1`** solo imprime el plan
  si no se le pasa `-Apply`, rompe la herencia copiando los permisos actuales y quita los grupos Miembros y Visitantes
  de cada lista. Con esto las notas internas quedan protegidas y ya no hace falta `DT_InternalNotes`.
- La app con el portal apagado: el menú y el inicio quedan solo para el staff, quien no es de D&T ve un aviso con
  el buzón y no se carga ningún dato.
- La consulta del rol tiene `IfError` y se detiene después de 3 intentos. Antes, alguien sin acceso a `DT_Users`
  generaba un error cada 5 segundos y llenaba el log.

### Flujos: ahora se ejecutan, no solo se revisan
- `gen_flows.py` es la única fuente de los flujos: cada expresión es un dato y el markdown se genera desde ahí.
- `wdl.py` es un evaluador de expresiones de Power Automate, deliberadamente conservador: evalúa las dos ramas de
  `if()` y falla con nulos.
- `flow_sim.py` simula SharePoint con sus mismos rechazos (texto de más de 255 caracteres, columnas obligatorias,
  valores únicos, tipos) y simula el correo, incluidas las respuestas de "fuera de oficina".
- `test_flow_sim.py` tiene 30 escenarios de punta a punta.
- **Bugs reales que encontró** (todos estaban en r2):
  - `cmpPrevNote` hacía `concat` con nulo. Si Power Automate evalúa las dos ramas del `if()`, todo ticket nuevo
    habría fallado.
  - `toLower(from)` sin `coalesce`.
  - La búsqueda por conversación con `conversationId` vacío podía unir correos que no tenían nada que ver.
  - Los asuntos `RV:` / `Fw:` no se limpiaban del título.
  - No había filtro para remitentes automáticos (`noreply`, `mailer-daemon`).
  - Desasignar y volver a asignar a la misma persona no la volvía a avisar (ahora `ACT_ASSIGN` limpia la marca de F2).
- F2 escapa la descripción en HTML.

### App
- El Dashboard tenía el % de respuesta a tiempo inflado: dejaba fuera los tickets vencidos sin respuesta. Ahora entran.
  "Unassigned" también muestra cuántos faltan por clasificar y cuántos ✉ están sin respuesta. Los tickets sin
  categoría salen como "🏷 to classify".
- Si D&T abre un ticket a nombre de alguien, se crea un aviso público y F3 se lo manda por correo a esa persona.
- Admin › errores incluye `flow-intake-failed`, que son los correos que no se convirtieron en ticket.
- Inicio: ✉ y "to classify" en la lista. Se corrigió el encimado del botón "Mark as read" con el título.

### Documentación
- **Corrección de empaque** (reporte de d3x-dev, pack bloqueado): la receta `pac canvas pack --sources build/Src`
  estaba mal, porque hace falta el carrier `.msapr`. Nuevo `docs/RUNBOOK_DEV_empaque_carrier.md` con el bootstrap de
  la cáscara en Studio (una vez) y el pack con `--layout SourceCode`. **El `Src` no cambió.**
- `docs/Runbook_Puesta_en_marcha.md`: orden de instalación A–C y 15 pruebas de aceptación en el tenant (D1–D15),
  cada una enlazada a su escenario del simulador.


## v1.0 r2 — El correo es el canal principal (2026-11-18)

Validado **0 errores / 0 avisos / 0 linter** + **44/44 pruebas** + 11 YAML válidos. **325 controles.**

- **Flujos nuevos** (`flows/`, generados por `gen_flows.py` desde el esquema):
  - **F1** convierte cada correo del buzón compartido en un ticket o en un comentario de seguimiento, y responde con un acuse que lleva el `[key]`.
  - **F2** avisa por correo a la persona asignada.
  - **F3** le manda al solicitante las respuestas públicas.
- **Esquema:**
  - `DT_Tickets` suma `Source`, `MailMessageId`, `MailConversationId`, `HasNewMessage` y `NotifiedAssigneeEmail`. `Category` deja de ser obligatoria, porque el ticket llega sin clasificar.
  - `DT_TicketComments` suma `MailMessageId` y `MailSentAt`, y un nuevo valor de `Kind`: `email`.
  - Índices nuevos en `BusinessKey`, `MailMessageId` y `MailConversationId`.
  - El script de provisión agrega las columnas a listas que ya existen; se puede volver a correr.
- **App:**
  - "Change priority" pasa a ser **🏷 Classify / Category / priority**: categoría, subcategoría, impacto y urgencia en una sola transición. Respeta la regla de oro y deja una fila de ChangeLog por cada campo.
  - La cola tiene los filtros **Needs triage** y **New messages**, muestra 🏷 y ✉ en cada fila y cuenta cuántos hay por clasificar y con mensajes nuevos.
  - En el ticket: "✉ by e-mail", los comentarios de correo identificados y el botón **✉ Mark as read**.
  - `SEND_REPLY` actualiza `HasNewMessage` y el cierre en bloque se salta tickets con ✉.
- **Pruebas** (+10, familia `TestFlows`):
  - Contrato de cada flujo con las listas.
  - El formato de key es el mismo en la app y en F1.
  - Protecciones contra bucles y duplicados.
  - El ✉ se mantiene consistente.
  - Verificado con mutaciones: un nombre de columna con error, un valor fuera de dominio o una columna obligatoria faltante hacen fallar la prueba.


## v1.0 r1 — Primer build (2026-11-18)

Validado **0 errores / 0 avisos / 0 linter** + **34/34 pruebas** + 11 YAML válidos. **322 controles.**
Esquema nuevo: 8 listas `DT_*` (provisionar con `Provision-DTTicketing.ps1` antes de importar).

### Pantallas (7) + componentes (2)
- `scrHome`: saludo, "Open a new ticket", "My tickets (N open)" y, para el staff, "Team queue (N to triage)"; abajo, los tickets recientes del solicitante o los asignados al agente.
- `scrNewTicket`: categoría → subcategoría → resumen → descripción → impacto/urgencia → hasta 3 capturas. **Antes de enviar** muestra la prioridad, el SLA y a quién se va a asignar. El staff puede abrir tickets a nombre de otra persona.
- `scrMyTickets`: los tickets propios, con filtros Open / Waiting for my confirmation / Closed / All y búsqueda.
- `scrQueue` (staff): cola ordenada por prioridad y fecha límite. Filtros: estado, prioridad, categoría, asignado, estado del SLA y búsqueda. Contadores de vencidos y sin asignar. Los leads pueden cerrar en bloque los resueltos de más de 5 días.
- `scrTicket`: encabezado con los relojes de respuesta y resolución, descripción, pestañas Conversation / Attachments / History, caja de respuesta (con nota interna para el staff) y panel de acciones por rol y estado.
- `scrDashboard` (staff): 8 indicadores (abiertos, sin asignar, vencidos, resueltos en 7 días, % de SLA de resolución y de respuesta a 30 días, tiempo medio de resolución sin contar la espera, reabiertos) y desgloses por prioridad, categoría y asignado.
- `scrAdmin`: staff y roles, categorías con ruteo automático (encender/apagar), SLA por prioridad y errores recientes.
- `cmpNav`, `cmpHeader`: fork directo de Colo2B (menú sin scroll filtrado por rol).

### Heredado de Colo2B (cada punto viene de un bug real)
Shell responsivo · `tmrNet` (red, rol y refresco cada 30 s) · sello `lblFresh` · rol persistido para arranques sin red · candado `gblWriting` · `IsError(Patch(...))` y nunca `IfError(Patch, Notify)` · regla de oro antes de escribir · bitácora aislada (si falla, no deshace la escritura) · `App.OnError` → `DT_AppLog` · fotos en base64 partidas en 16 trozos.

### Cambios al motor en el fork (con prueba que demuestra cada uno)
- `checks.py`: las expresiones regulares de listas `OD_` → `DT_` (Patch, LookUp/galería y alcance de componentes). **Sin esto, el validador se habría saltado en silencio todas las listas DT.**
- `checks.py`: exención de solapes generalizada a cualquier variable `gbl…Mode = "x"` (antes solo `gblQualMode`).
- `checks.py`: en los `Filter`, los nombres `num…` (fórmulas con nombre) ya no se toman por columnas.
- `build.py` / `_fastval.py`: el linter corre en el mismo proceso y forma parte del gate.
- `powerfx_lint.py`: el perfil se deriva del esquema (listas y columnas de texto) y de `App.Formulas` (UDF). PXF110, PXF103 y PXF119 ya no marcan colecciones locales `col*`, porque no hay delegación que perder.
- `gen_provision.py`: índices en todas las columnas que la app filtra en el servidor (verificado por prueba), columnas de varias líneas en texto plano y sin append, y semilla idempotente.

### Pendientes de decisión
1. Notas internas en una lista aparte con permisos solo para D&T (ver los límites en el README).
2. Notificaciones por correo (Power Automate) al crear, asignar, resolver y cuando el ticket queda en espera del solicitante.
3. SLA en horas hábiles (calendario laboral).
4. Encuesta de satisfacción al cerrar (la columna `Satisfaction` ya existe en el esquema).
