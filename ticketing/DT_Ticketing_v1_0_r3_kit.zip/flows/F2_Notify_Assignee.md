# F2 — DT Notify assignee

**Trigger:** SharePoint › *When an item is created or modified* · Site `https://<tenant>.sharepoint.com/sites/<site>` · List `DT_Tickets`.

**Trigger conditions** (both):
```
@not(empty(triggerOutputs()?['body/AssignedToEmail']))
```
```
@not(equals(toLower(coalesce(triggerOutputs()?['body/AssignedToEmail'], '')), toLower(coalesce(triggerOutputs()?['body/NotifiedAssigneeEmail'], ''))))
```
It runs only when there is an assignee **who has not been notified yet**. When step 2 writes the mark, the flow fires again with the condition false, so there is no loop.

## Actions
1. Condition `selfAssigned`: `@equals(toLower(triggerOutputs()?['body/AssignedToEmail']), toLower(coalesce(triggerOutputs()?['body/LastActivityBy'], '')))`
   - **No** (someone else assigned it) → Send an email from a shared mailbox (V2): From `dt-support@company.com` · To `triggerOutputs()?['body/AssignedToEmail']` · Subject:
```
[@{triggerOutputs()?['body/BusinessKey']}] Assigned to you: @{triggerOutputs()?['body/Title']}
```
     Body (HTML):
```
<p><b>@{triggerOutputs()?['body/BusinessKey']}</b> — @{triggerOutputs()?['body/Title']}</p><p>Priority <b>@{triggerOutputs()?['body/Priority']}</b> · Requester @{coalesce(triggerOutputs()?['body/RequesterName'], triggerOutputs()?['body/RequesterEmail'])} · Resolution due @{formatDateTime(triggerOutputs()?['body/ResolutionDueAt'], 'dd-MMM HH:mm')} (UTC)</p><p>@{replace(replace(replace(take(coalesce(triggerOutputs()?['body/Description'], ''), 600), '&', '&amp;'), '<', '&lt;'), '>', '&gt;')}</p><p><a href='https://apps.powerapps.com/play/<app id>'>Open the Service Desk</a></p>
```
   - **Yes** (they took it themselves with "Take it") → no e-mail.
2. Update item `DT_Tickets` (Id: `triggerOutputs()?['body/ID']`), in **both** branches:

| Column | Value (expression) |
|---|---|
| `NotifiedAssigneeEmail` | `triggerOutputs()?['body/AssignedToEmail']` |

> **Update item** (SharePoint) asks for the list's required columns: the ones NOT in the table get the CURRENT value of the row you read (`RowGuid, BusinessKey, Impact, Urgency, Priority, Status, RequesterEmail, CreatedAt`), never a new one.

Optional: in addition to the e-mail, Microsoft Teams › *Post message in a chat or channel* to the D&T channel (standard connector).
