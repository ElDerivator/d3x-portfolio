# F1 — DT Intake: e-mail → ticket

**Trigger:** Office 365 Outlook › *When a new email arrives in a shared mailbox (V2)*
· Mailbox: `dt-support@company.com` · Folder: Inbox · Include attachments: **Yes** · Only with attachments: No.

**Trigger settings:**
- **Concurrency control: ON, degree 1.** Mails are processed one at a time, so two mails cannot create the same ticket twice.
- **Trigger conditions** (all; replace `company.com` / `dt-support@company.com` with yours):
```
@endsWith(toLower(coalesce(triggerOutputs()?['body/from'], '')), '@company.com')
```
```
@not(equals(toLower(coalesce(triggerOutputs()?['body/from'], '')), 'dt-support@company.com'))
```
```
@not(or(startsWith(toLower(coalesce(triggerOutputs()?['body/subject'], '')), 'automatic reply'), startsWith(toLower(coalesce(triggerOutputs()?['body/subject'], '')), 'auto:'), startsWith(toLower(coalesce(triggerOutputs()?['body/subject'], '')), 'out of office'), startsWith(toLower(coalesce(triggerOutputs()?['body/subject'], '')), 'undeliverable'), startsWith(toLower(coalesce(triggerOutputs()?['body/subject'], '')), 'delivery status notification'), startsWith(toLower(coalesce(triggerOutputs()?['body/subject'], '')), 'respuesta automática'), startsWith(toLower(coalesce(triggerOutputs()?['body/subject'], '')), 'no entregable'), startsWith(toLower(coalesce(triggerOutputs()?['body/subject'], '')), 'fuera de la oficina')))
```
```
@not(or(startsWith(toLower(coalesce(triggerOutputs()?['body/from'], '')), 'noreply'), startsWith(toLower(coalesce(triggerOutputs()?['body/from'], '')), 'no-reply'), startsWith(toLower(coalesce(triggerOutputs()?['body/from'], '')), 'donotreply'), startsWith(toLower(coalesce(triggerOutputs()?['body/from'], '')), 'mailer-daemon'), startsWith(toLower(coalesce(triggerOutputs()?['body/from'], '')), 'postmaster')))
```
  1) internal senders only · 2) never the mailbox itself · 3) no auto-replies or bounces · 4) no robot senders.
  (Without 3, the ack this flow sends would loop forever against an out-of-office.)

## 0 · Variables and data (top level, before the Try scope)
| Action | Name | Value |
|---|---|---|
| Initialize variable (String) | `varTicketGuid` | `''` |
| Initialize variable (String) | `varCommentGuid` | `''` |
| Initialize variable (Array) | `varSkipped` | `createArray()` |
| Compose | `cmpFrom` | `toLower(coalesce(triggerOutputs()?['body/from'], ''))` |
| Compose | `cmpSubject` | `coalesce(triggerOutputs()?['body/subject'], '(no subject)')` |
| Compose | `cmpMsgId` | `coalesce(triggerOutputs()?['body/internetMessageId'], '')` |
| Compose | `cmpConv` | `coalesce(triggerOutputs()?['body/conversationId'], '')` |
| Compose | `cmpIdx` | `indexOf(outputs('cmpSubject'), '[DT-')` |
| Compose | `cmpKeyRaw` | `substring(concat(outputs('cmpSubject'), '                '), add(outputs('cmpIdx'), 1), 14)` |
| Compose | `cmpKey` | `if(and(greater(outputs('cmpIdx'), -1), startsWith(outputs('cmpKeyRaw'), 'DT-')), toUpper(outputs('cmpKeyRaw')), '')` |
| Content Conversion › Html to text | `Html_to_text` | Content: `coalesce(triggerOutputs()?['body/body'], '')` |
| Office 365 Users › Get user profile (V2) | `Get_user_profile` | UPN: `outputs('cmpFrom')` · **Configure run after: is successful + has failed** (no profile for shared/external senders) |
| Compose | `cmpFromName` | `coalesce(body('Get_user_profile')?['displayName'], outputs('cmpFrom'))` |
| Compose | `cmpFromDept` | `coalesce(body('Get_user_profile')?['department'], '')` |

The key is `DT-yymmdd-XXXX` (14 characters), the same format the app creates. The padding in `cmpKeyRaw` keeps `substring` valid when the subject is short.

## Scope "Try"

### 1 · Duplicate check (the trigger can fire twice for one mail)
- SharePoint › Get items `getDupT`: list `DT_Tickets`, Filter Query `MailMessageId eq '@{replace(outputs('cmpMsgId'), '''', '''''')}'`, Top 1.
- SharePoint › Get items `getDupC`: list `DT_TicketComments`, same Filter Query, Top 1.
- Condition: `@and(not(empty(outputs('cmpMsgId'))), greater(add(length(body('getDupT')?['value']), length(body('getDupC')?['value'])), 0))` → **Yes: Terminate (Succeeded)**.

### 2 · Is it a follow-up of a ticket?
- Get items `getByKey`: `DT_Tickets`, Filter `BusinessKey eq '@{outputs('cmpKey')}'`, Top 1.
- Get items `getByConv`: `DT_Tickets`, Filter `MailConversationId eq '@{replace(outputs('cmpConv'), '''', '''''')}'`, Order by `Created desc`, Top 1.
- Compose `cmpTicket`:
```
if(greater(length(body('getByKey')?['value']), 0), first(body('getByKey')?['value']), if(and(not(empty(outputs('cmpConv'))), greater(length(body('getByConv')?['value']), 0)), first(body('getByConv')?['value']), null))
```
- Condition `isFollowUp`: `@and(not(equals(outputs('cmpTicket'), null)), not(contains(createArray('Closed', 'Cancelled'), coalesce(outputs('cmpTicket')?['Status'], ''))))`

### 3-YES · Follow-up → comment on the ticket
- Set variable `varTicketGuid` = `outputs('cmpTicket')?['RowGuid']` · Set variable `varCommentGuid` = `guid()`.
- **Y2** Create item `DT_TicketComments`. Only the new text is kept: the quoted thread below "From:" / "De:" / "-----Original Message-----" is cut.

| Column | Value (expression) |
|---|---|
| `Title` | `'email'` |
| `RowGuid` | `variables('varCommentGuid')` |
| `BusinessKey` | `concat('COM-', formatDateTime(utcNow(), 'yyyyMMddHHmmss'), '-', substring(guid(), 0, 6))` |
| `Ticket_GUID` | `outputs('cmpTicket')?['RowGuid']` |
| `Body` | `take(trim(first(split(first(split(first(split(body('Html_to_text'), decodeUriComponent('%0AFrom:%20'))), decodeUriComponent('%0ADe:%20'))), '-----Original Message-----'))), 30000)` |
| `AuthorEmail` | `outputs('cmpFrom')` |
| `AuthorName` | `outputs('cmpFromName')` |
| `IsInternal` | `false` |
| `Kind` | `'email'` |
| `CreatedAt` | `triggerOutputs()?['body/receivedDateTime']` |
| `MailMessageId` | `outputs('cmpMsgId')` |

- **Y3** Condition `resume`:
  `@and(equals(outputs('cmpTicket')?['Status'], 'On Hold'), equals(outputs('cmpTicket')?['HoldReason'], 'Waiting on requester'), not(empty(outputs('cmpTicket')?['OnHoldSince'])), equals(outputs('cmpFrom'), toLower(coalesce(outputs('cmpTicket')?['RequesterEmail'], ''))))`
  - **Yes (Y3a):** Update item `DT_Tickets` (Id: `outputs('cmpTicket')?['ID']`). This is the same resume the app applies when the requester replies there.

| Column | Value (expression) |
|---|---|
| `Status` | `'In Progress'` |
| `HoldMinutes` | `add(coalesce(outputs('cmpTicket')?['HoldMinutes'], 0), div(sub(ticks(utcNow()), ticks(outputs('cmpTicket')?['OnHoldSince'])), 600000000))` |
| `ResolutionDueAt` | `addMinutes(outputs('cmpTicket')?['ResolutionDueAt'], div(sub(ticks(utcNow()), ticks(outputs('cmpTicket')?['OnHoldSince'])), 600000000))` |
| `OnHoldSince` | `null` |
| `HasNewMessage` | `true` |
| `LastActivityAt` | `utcNow()` |
| `LastActivityBy` | `outputs('cmpFrom')` |

> **Update item** (SharePoint) asks for the list's required columns: the ones NOT in the table get the CURRENT value of the row you read (`RowGuid, BusinessKey, Impact, Urgency, Priority, Status, RequesterEmail, CreatedAt`), never a new one.

  Then Create item `DT_ChangeLog`:

| Column | Value (expression) |
|---|---|
| `Title` | `'Status'` |
| `RowGuid` | `guid()` |
| `BusinessKey` | `concat('CHG-', formatDateTime(utcNow(), 'yyyyMMddHHmmss'), '-', substring(guid(), 0, 6))` |
| `Ticket_GUID` | `outputs('cmpTicket')?['RowGuid']` |
| `Field` | `'Status'` |
| `OldValue` | `'On Hold'` |
| `NewValue` | `'In Progress'` |
| `ChangeType` | `'status'` |
| `Reason` | `'requester replied by e-mail'` |
| `ChangedBy` | `outputs('cmpFrom')` |
| `ChangedAt` | `utcNow()` |

  - **No (Y3b):** Update item `DT_Tickets` (Id: `outputs('cmpTicket')?['ID']`). A message on a **Resolved** ticket does **not** reopen it ("thanks!" would); it raises ✉ and the agent decides.

| Column | Value (expression) |
|---|---|
| `HasNewMessage` | `not(equals(outputs('cmpFrom'), toLower(coalesce(outputs('cmpTicket')?['AssignedToEmail'], ''))))` |
| `LastActivityAt` | `utcNow()` |
| `LastActivityBy` | `outputs('cmpFrom')` |

### 3-NO · New ticket
(Also when the [key] belongs to a Closed/Cancelled ticket: a new one is opened that cites it.)
- Set variable `varTicketGuid` = `guid()`.
- Compose `cmpNewKey`: `concat('DT-', formatDateTime(utcNow(), 'yyMMdd'), '-', toUpper(substring(variables('varTicketGuid'), 0, 4)))`
- Compose `cmpTitle`: `take(trim(replace(replace(replace(replace(replace(replace(outputs('cmpSubject'), 'RE: ', ''), 'Re: ', ''), 'FW: ', ''), 'Fw: ', ''), 'Fwd: ', ''), 'RV: ', '')), 250)`
- Compose `cmpPrevNote`: `if(equals(outputs('cmpTicket'), null), '', concat('Follow-up of ', coalesce(outputs('cmpTicket')?['BusinessKey'], ''), ' (closed). ', decodeUriComponent('%0A%0A')))`
- Get items `getSla`: `DT_SLAPolicy`, Filter `Priority eq 'P3' and Active eq 1`, Top 1.
- Compose `cmpRespH`: `coalesce(first(body('getSla')?['value'])?['ResponseHours'], 8)` · Compose `cmpResH`: `coalesce(first(body('getSla')?['value'])?['ResolutionHours'], 72)`
- **N4** Create item `DT_Tickets`. It arrives **unclassified** (blank Category, Medium/Medium = provisional P3). The SLA clock starts when the mail arrives; "🏷 Classify" in the app recalculates the due dates from that same moment.

| Column | Value (expression) |
|---|---|
| `Title` | `outputs('cmpTitle')` |
| `RowGuid` | `variables('varTicketGuid')` |
| `BusinessKey` | `outputs('cmpNewKey')` |
| `Description` | `take(concat(outputs('cmpPrevNote'), trim(body('Html_to_text'))), 30000)` |
| `Category` | `''` |
| `Subcategory` | `''` |
| `Impact` | `'Medium'` |
| `Urgency` | `'Medium'` |
| `Priority` | `'P3'` |
| `Status` | `'New'` |
| `RequesterEmail` | `outputs('cmpFrom')` |
| `RequesterName` | `outputs('cmpFromName')` |
| `RequesterDept` | `outputs('cmpFromDept')` |
| `CreatedAt` | `triggerOutputs()?['body/receivedDateTime']` |
| `ResponseDueAt` | `addSeconds(triggerOutputs()?['body/receivedDateTime'], int(formatNumber(mul(outputs('cmpRespH'), 3600), '0')))` |
| `ResolutionDueAt` | `addSeconds(triggerOutputs()?['body/receivedDateTime'], int(formatNumber(mul(outputs('cmpResH'), 3600), '0')))` |
| `HoldMinutes` | `0` |
| `ReopenCount` | `0` |
| `Source` | `'Email'` |
| `MailMessageId` | `outputs('cmpMsgId')` |
| `MailConversationId` | `outputs('cmpConv')` |
| `HasNewMessage` | `false` |
| `LastActivityAt` | `utcNow()` |
| `LastActivityBy` | `outputs('cmpFrom')` |

- **N5** Create item `DT_ChangeLog`:

| Column | Value (expression) |
|---|---|
| `Title` | `'Status'` |
| `RowGuid` | `guid()` |
| `BusinessKey` | `concat('CHG-', formatDateTime(utcNow(), 'yyyyMMddHHmmss'), '-', substring(guid(), 0, 6))` |
| `Ticket_GUID` | `variables('varTicketGuid')` |
| `Field` | `'Status'` |
| `OldValue` | `''` |
| `NewValue` | `'New'` |
| `ChangeType` | `'status'` |
| `Reason` | `'created from e-mail'` |
| `ChangedBy` | `outputs('cmpFrom')` |
| `ChangedAt` | `utcNow()` |

- **N6** Send an email from a shared mailbox (V2): From `dt-support@company.com` · To `outputs('cmpFrom')` · Subject:
```
[@{outputs('cmpNewKey')}] @{outputs('cmpTitle')}
```
  Body (HTML):
```
<p>Hi,</p><p>We received your request and opened ticket <b>@{outputs('cmpNewKey')}</b>. The Data &amp; Technology team will review it and assign it.</p><p>To add information, <b>reply to this e-mail</b> and keep <b>[@{outputs('cmpNewKey')}]</b> in the subject.</p><p>— Data &amp; Technology Service Desk</p>
```

### 4 · Attachments (after the condition, both branches)
Apply to each `Apply_to_each_attachment` over `coalesce(triggerOutputs()?['body/attachments'], createArray())`:
- Condition **A1**:
```
@and(startsWith(toLower(coalesce(items('Apply_to_each_attachment')?['contentType'], '')), 'image/'), lessOrEquals(length(coalesce(items('Apply_to_each_attachment')?['contentBytes'], '')), 940000), or(equals(items('Apply_to_each_attachment')?['isInline'], false), greater(coalesce(items('Apply_to_each_attachment')?['size'], 0), 15000)))
```
  Images only (the app can display only those), up to ~700 KB. Small inline images (signature logos) are skipped; screenshots pasted into the body are kept.
  - **Yes:** Compose `cmpB64` = `concat('data:', items('Apply_to_each_attachment')?['contentType'], ';base64,', items('Apply_to_each_attachment')?['contentBytes'])`, then **A2** Create item `DT_Attachments`. These are the same 16 chunks of 60,000 the app writes, and `slice()` returns `''` past the end:

| Column | Value (expression) |
|---|---|
| `Title` | `'email'` |
| `RowGuid` | `guid()` |
| `BusinessKey` | `concat('ATT-', formatDateTime(utcNow(), 'yyyyMMddHHmmss'), '-', substring(guid(), 0, 6))` |
| `Ticket_GUID` | `variables('varTicketGuid')` |
| `Comment_GUID` | `variables('varCommentGuid')` |
| `FileName` | `items('Apply_to_each_attachment')?['name']` |
| `EvidenceB64` | `slice(outputs('cmpB64'), 0, 60000)` |
| `EvidenceB64_2` | `slice(outputs('cmpB64'), 60000, 120000)` |
| `EvidenceB64_3` | `slice(outputs('cmpB64'), 120000, 180000)` |
| `EvidenceB64_4` | `slice(outputs('cmpB64'), 180000, 240000)` |
| `EvidenceB64_5` | `slice(outputs('cmpB64'), 240000, 300000)` |
| `EvidenceB64_6` | `slice(outputs('cmpB64'), 300000, 360000)` |
| `EvidenceB64_7` | `slice(outputs('cmpB64'), 360000, 420000)` |
| `EvidenceB64_8` | `slice(outputs('cmpB64'), 420000, 480000)` |
| `EvidenceB64_9` | `slice(outputs('cmpB64'), 480000, 540000)` |
| `EvidenceB64_10` | `slice(outputs('cmpB64'), 540000, 600000)` |
| `EvidenceB64_11` | `slice(outputs('cmpB64'), 600000, 660000)` |
| `EvidenceB64_12` | `slice(outputs('cmpB64'), 660000, 720000)` |
| `EvidenceB64_13` | `slice(outputs('cmpB64'), 720000, 780000)` |
| `EvidenceB64_14` | `slice(outputs('cmpB64'), 780000, 840000)` |
| `EvidenceB64_15` | `slice(outputs('cmpB64'), 840000, 900000)` |
| `EvidenceB64_16` | `slice(outputs('cmpB64'), 900000, 960000)` |
| `UploadedBy` | `outputs('cmpFrom')` |
| `UploadedAt` | `triggerOutputs()?['body/receivedDateTime']` |

  - **No:** Condition `@not(equals(items('Apply_to_each_attachment')?['isInline'], true))` → Append to array variable `varSkipped`: `concat(coalesce(items('Apply_to_each_attachment')?['name'], 'file'), ' (', coalesce(items('Apply_to_each_attachment')?['contentType'], '?'), ', ', div(coalesce(items('Apply_to_each_attachment')?['size'], 0), 1024), ' KB)')`
- After the loop: Condition `@greater(length(variables('varSkipped')), 0)` → **A3** Create item `DT_TicketComments` (internal note, D&T only):

| Column | Value (expression) |
|---|---|
| `Title` | `'system'` |
| `RowGuid` | `guid()` |
| `BusinessKey` | `concat('COM-', formatDateTime(utcNow(), 'yyyyMMddHHmmss'), '-', substring(guid(), 0, 6))` |
| `Ticket_GUID` | `variables('varTicketGuid')` |
| `Body` | `concat('Attachments not stored (not an image, or larger than ~700 KB) — find them in the D&T mailbox: ', join(variables('varSkipped'), '; '))` |
| `AuthorEmail` | `'dt-support@company.com'` |
| `AuthorName` | `'D&T mailbox'` |
| `IsInternal` | `true` |
| `Kind` | `'system'` |
| `CreatedAt` | `utcNow()` |

## Scope "Catch" (Configure run after: Try **has failed / has timed out**)
Create item `DT_AppLog`; the app's Admin screen lists it under "recent errors":

| Column | Value (expression) |
|---|---|
| `Title` | `'flow-intake-failed'` |
| `RowGuid` | `guid()` |
| `BusinessKey` | `concat('LOG-', formatDateTime(utcNow(), 'yyyyMMddHHmmss'), '-', substring(guid(), 0, 6))` |
| `Event` | `'flow-intake-failed'` |
| `Detail` | `concat(outputs('cmpFrom'), ' · ', triggerOutputs()?['body/subject'], ' · ', workflow()?['run']?['name'])` |
| `ScreenName` | `'F1 intake'` |
| `UserEmail` | `outputs('cmpFrom')` |
| `At` | `utcNow()` |
| `AppVersion` | `'flow'` |
| `Success` | `false` |

Then **Terminate (Failed)**: the run stays red in the history, and Power Automate e-mails the owner.
