# F3 — DT Reply to requester

**Trigger:** SharePoint › *When an item is created* · List `DT_TicketComments`.

**Trigger conditions** (all three):
```
@equals(triggerOutputs()?['body/IsInternal'], false)
```
```
@or(equals(triggerOutputs()?['body/Kind'], 'reply'), equals(triggerOutputs()?['body/Kind'], 'system'))
```
```
@empty(triggerOutputs()?['body/MailSentAt'])
```
Public messages only: a D&T reply, or the system notices the app writes (opened for you, on hold, resolved, cancelled, reopened).
Internal notes and inbound e-mails (`Kind = email`) never leave.

## Actions
1. Get items `getT`: `DT_Tickets`, Filter `RowGuid eq '@{triggerOutputs()?['body/Ticket_GUID']}'`, Top 1 → Compose `cmpT` = `first(body('getT')?['value'])`.
2. Condition: `@and(not(equals(outputs('cmpT'), null)), not(equals(toLower(coalesce(triggerOutputs()?['body/AuthorEmail'], '')), toLower(coalesce(outputs('cmpT')?['RequesterEmail'], '')))))`
   (the requester is never e-mailed what they wrote themselves).
3. **Yes** → Send an email from a shared mailbox (V2): From `dt-support@company.com` · To `outputs('cmpT')?['RequesterEmail']` · Subject:
```
[@{outputs('cmpT')?['BusinessKey']}] @{outputs('cmpT')?['Title']}
```
   Body (HTML):
```
<p>@{replace(replace(replace(replace(coalesce(triggerOutputs()?['body/Body'], ''), '&', '&amp;'), '<', '&lt;'), '>', '&gt;'), decodeUriComponent('%0A'), '<br>')}</p><p>— @{coalesce(triggerOutputs()?['body/AuthorName'], 'Data &amp; Technology')}, Data &amp; Technology</p><p style='color:#5a6b82'>Ticket @{outputs('cmpT')?['BusinessKey']} · status: @{outputs('cmpT')?['Status']}. Reply to this e-mail to answer (keep [@{outputs('cmpT')?['BusinessKey']}] in the subject).</p>
```
   The body is escaped (`& < >`): what was written in the app arrives as text, never as HTML.
4. Update item `DT_TicketComments` (Id: `triggerOutputs()?['body/ID']`), only in the Yes branch:

| Column | Value (expression) |
|---|---|
| `MailSentAt` | `utcNow()` |

> **Update item** (SharePoint) asks for the list's required columns: the ones NOT in the table get the CURRENT value of the row you read (`RowGuid, BusinessKey, Ticket_GUID, Body, AuthorEmail, Kind, CreatedAt`), never a new one.

The subject keeps the `[key]`, so the requester's reply goes back into F1 as a comment on the same ticket.
