﻿# ============================================================================
# Provision-DTTicketing.ps1  —  GENERATED from tools/gen/sharepoint_schema.py
# Data & Technology Ticketing System · 8 lists · schema sealed 2026-11-18 12:40
# Idempotent: safe to re-run; a re-run is the drift check. PnP.PowerShell only.
#
# Model rules (same as Colo2B):
#  · RowGuid = UNIQUE key (indexed + EnforceUniqueValues). Never the native Id.
#  · *_GUID columns hold the RowGuid of another list. No Lookup columns.
#  · Domain columns (Status, Priority, Role...) are TEXT; the app validates the domain.
#  · Title is made NOT required. Multi-line columns: plain text, no append.
#
# Usage:
#   Install-Module PnP.PowerShell -Scope CurrentUser
#   .\Provision-DTTicketing.ps1 -SiteUrl https://<tenant>.sharepoint.com/sites/<site> -AdminEmail you@company.com
#   (newer PnP versions also need: -ClientId <your Entra app id>; see README)
# ============================================================================
param(
  [Parameter(Mandatory=$true)][string]$SiteUrl,
  [Parameter(Mandatory=$true)][string]$AdminEmail,
  [string]$AdminName = "",
  [string]$ClientId = ""
)
$ErrorActionPreference = "Stop"
if($ClientId){ Connect-PnPOnline -Url $SiteUrl -Interactive -ClientId $ClientId } else { Connect-PnPOnline -Url $SiteUrl -Interactive }
Write-Host "Connected to $SiteUrl" -ForegroundColor Cyan

function Ensure-List([string]$Title){
  $l = Get-PnPList -Identity $Title -ErrorAction SilentlyContinue
  if(-not $l){ $l = New-PnPList -Title $Title -Template GenericList -OnQuickLaunch:$false
              Write-Host "  + list $Title" -ForegroundColor Green }
  else      { Write-Host "  = list $Title (exists)" }
  Set-PnPField -List $Title -Identity "Title" -Values @{Required=$false} | Out-Null
  return $l
}

function Ensure-Field([string]$List,[string]$Name,[string]$Type,[bool]$Required,[bool]$Unique,[bool]$Indexed){
  $f = Get-PnPField -List $List -Identity $Name -ErrorAction SilentlyContinue
  if(-not $f){
    Add-PnPField -List $List -DisplayName $Name -InternalName $Name -Type $Type -AddToDefaultView | Out-Null
    Write-Host "    + $List.$Name ($Type)" -ForegroundColor Green
  } else { Write-Host "    = $List.$Name" }
  $vals = @{ Required = $Required }
  if($Unique -or $Indexed){ Set-PnPField -List $List -Identity $Name -Values @{Indexed=$true} | Out-Null }
  if($Unique){ $vals['EnforceUniqueValues'] = $true }
  if($Type -eq 'Note'){ $vals['RichText'] = $false; $vals['AppendOnly'] = $false; $vals['UnlimitedLengthInDocumentLibrary'] = $true }
  Set-PnPField -List $List -Identity $Name -Values $vals | Out-Null
}

function Ensure-Item([string]$List,[string]$Key,[hashtable]$Values){
  $q = "<View><Query><Where><Eq><FieldRef Name='BusinessKey'/><Value Type='Text'>$Key</Value></Eq></Where></Query></View>"
  $hit = Get-PnPListItem -List $List -Query $q
  if(-not $hit){ $Values['BusinessKey'] = $Key; $Values['RowGuid'] = [guid]::NewGuid().ToString()
               Add-PnPListItem -List $List -Values $Values | Out-Null
               Write-Host "    + $List $Key" -ForegroundColor Green }
  else       { Write-Host "    = $List $Key (exists, left as is)" }
}

# --- lists + columns --------------------------------------------------------
Write-Host "DT_Tickets" -ForegroundColor Yellow
Ensure-List "DT_Tickets" | Out-Null
Ensure-Field "DT_Tickets" "RowGuid" "Text" $true $true $false
Ensure-Field "DT_Tickets" "BusinessKey" "Text" $true $false $true
Ensure-Field "DT_Tickets" "Description" "Note" $false $false $false
Ensure-Field "DT_Tickets" "Category" "Text" $false $false $false
Ensure-Field "DT_Tickets" "Subcategory" "Text" $false $false $false
#   domain Impact: High, Medium, Low
Ensure-Field "DT_Tickets" "Impact" "Text" $true $false $false
#   domain Urgency: High, Medium, Low
Ensure-Field "DT_Tickets" "Urgency" "Text" $true $false $false
#   domain Priority: P1, P2, P3, P4
Ensure-Field "DT_Tickets" "Priority" "Text" $true $false $false
#   domain Status: New, Assigned, In Progress, On Hold, Resolved, Closed, Cancelled
Ensure-Field "DT_Tickets" "Status" "Text" $true $false $true
Ensure-Field "DT_Tickets" "RequesterEmail" "Text" $true $false $true
Ensure-Field "DT_Tickets" "RequesterName" "Text" $false $false $false
Ensure-Field "DT_Tickets" "RequesterDept" "Text" $false $false $false
Ensure-Field "DT_Tickets" "AssignedToEmail" "Text" $false $false $true
Ensure-Field "DT_Tickets" "AssignedToName" "Text" $false $false $false
Ensure-Field "DT_Tickets" "CreatedAt" "DateTime" $true $false $true
Ensure-Field "DT_Tickets" "FirstResponseAt" "DateTime" $false $false $false
Ensure-Field "DT_Tickets" "ResolvedAt" "DateTime" $false $false $false
Ensure-Field "DT_Tickets" "ClosedAt" "DateTime" $false $false $true
Ensure-Field "DT_Tickets" "ResponseDueAt" "DateTime" $false $false $false
Ensure-Field "DT_Tickets" "ResolutionDueAt" "DateTime" $false $false $false
Ensure-Field "DT_Tickets" "OnHoldSince" "DateTime" $false $false $false
Ensure-Field "DT_Tickets" "HoldMinutes" "Number" $false $false $false
#   domain HoldReason: Waiting on requester, Waiting on third party, Waiting on approval, Scheduled
Ensure-Field "DT_Tickets" "HoldReason" "Text" $false $false $false
Ensure-Field "DT_Tickets" "Resolution" "Note" $false $false $false
#   domain ResolutionCode: Fixed, Delivered, Workaround, No action needed, Duplicate, Cannot reproduce
Ensure-Field "DT_Tickets" "ResolutionCode" "Text" $false $false $false
Ensure-Field "DT_Tickets" "ReopenCount" "Number" $false $false $false
Ensure-Field "DT_Tickets" "LastActivityAt" "DateTime" $false $false $false
Ensure-Field "DT_Tickets" "LastActivityBy" "Text" $false $false $false
Ensure-Field "DT_Tickets" "Satisfaction" "Number" $false $false $false
#   domain Source: Email, App
Ensure-Field "DT_Tickets" "Source" "Text" $false $false $false
Ensure-Field "DT_Tickets" "MailMessageId" "Text" $false $false $true
Ensure-Field "DT_Tickets" "MailConversationId" "Text" $false $false $true
Ensure-Field "DT_Tickets" "HasNewMessage" "Boolean" $false $false $false
Ensure-Field "DT_Tickets" "NotifiedAssigneeEmail" "Text" $false $false $false

Write-Host "DT_TicketComments" -ForegroundColor Yellow
Ensure-List "DT_TicketComments" | Out-Null
Ensure-Field "DT_TicketComments" "RowGuid" "Text" $true $true $false
Ensure-Field "DT_TicketComments" "BusinessKey" "Text" $true $false $false
Ensure-Field "DT_TicketComments" "Ticket_GUID" "Text" $true $false $true
Ensure-Field "DT_TicketComments" "Body" "Note" $true $false $false
Ensure-Field "DT_TicketComments" "AuthorEmail" "Text" $true $false $false
Ensure-Field "DT_TicketComments" "AuthorName" "Text" $false $false $false
Ensure-Field "DT_TicketComments" "IsInternal" "Boolean" $false $false $true
#   domain Kind: reply, note, system, email
Ensure-Field "DT_TicketComments" "Kind" "Text" $true $false $false
Ensure-Field "DT_TicketComments" "CreatedAt" "DateTime" $true $false $false
Ensure-Field "DT_TicketComments" "MailMessageId" "Text" $false $false $true
Ensure-Field "DT_TicketComments" "MailSentAt" "DateTime" $false $false $false

Write-Host "DT_Attachments" -ForegroundColor Yellow
Ensure-List "DT_Attachments" | Out-Null
Ensure-Field "DT_Attachments" "RowGuid" "Text" $true $true $false
Ensure-Field "DT_Attachments" "BusinessKey" "Text" $true $false $false
Ensure-Field "DT_Attachments" "Ticket_GUID" "Text" $true $false $true
Ensure-Field "DT_Attachments" "Comment_GUID" "Text" $false $false $false
Ensure-Field "DT_Attachments" "FileName" "Text" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_2" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_3" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_4" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_5" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_6" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_7" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_8" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_9" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_10" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_11" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_12" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_13" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_14" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_15" "Note" $false $false $false
Ensure-Field "DT_Attachments" "EvidenceB64_16" "Note" $false $false $false
Ensure-Field "DT_Attachments" "UploadedBy" "Text" $false $false $false
Ensure-Field "DT_Attachments" "UploadedAt" "DateTime" $false $false $false

Write-Host "DT_ChangeLog" -ForegroundColor Yellow
Ensure-List "DT_ChangeLog" | Out-Null
Ensure-Field "DT_ChangeLog" "RowGuid" "Text" $true $true $false
Ensure-Field "DT_ChangeLog" "BusinessKey" "Text" $true $false $false
Ensure-Field "DT_ChangeLog" "Ticket_GUID" "Text" $true $false $true
Ensure-Field "DT_ChangeLog" "Field" "Text" $true $false $false
Ensure-Field "DT_ChangeLog" "OldValue" "Text" $false $false $false
Ensure-Field "DT_ChangeLog" "NewValue" "Text" $false $false $false
#   domain ChangeType: status, assignment, priority, category, edit, sla
Ensure-Field "DT_ChangeLog" "ChangeType" "Text" $true $false $false
Ensure-Field "DT_ChangeLog" "Reason" "Note" $false $false $false
Ensure-Field "DT_ChangeLog" "ChangedBy" "Text" $true $false $false
Ensure-Field "DT_ChangeLog" "ChangedAt" "DateTime" $true $false $false

Write-Host "DT_Categories" -ForegroundColor Yellow
Ensure-List "DT_Categories" | Out-Null
Ensure-Field "DT_Categories" "RowGuid" "Text" $true $true $false
Ensure-Field "DT_Categories" "BusinessKey" "Text" $true $false $false
Ensure-Field "DT_Categories" "Name" "Text" $true $false $false
Ensure-Field "DT_Categories" "Parent" "Text" $false $false $false
Ensure-Field "DT_Categories" "Description" "Text" $false $false $false
Ensure-Field "DT_Categories" "DefaultAssigneeEmail" "Text" $false $false $false
Ensure-Field "DT_Categories" "SortOrder" "Number" $false $false $false
Ensure-Field "DT_Categories" "Active" "Boolean" $false $false $true

Write-Host "DT_SLAPolicy" -ForegroundColor Yellow
Ensure-List "DT_SLAPolicy" | Out-Null
Ensure-Field "DT_SLAPolicy" "RowGuid" "Text" $true $true $false
Ensure-Field "DT_SLAPolicy" "BusinessKey" "Text" $true $false $false
#   domain Priority: P1, P2, P3, P4
Ensure-Field "DT_SLAPolicy" "Priority" "Text" $true $false $false
Ensure-Field "DT_SLAPolicy" "ResponseHours" "Number" $true $false $false
Ensure-Field "DT_SLAPolicy" "ResolutionHours" "Number" $true $false $false
Ensure-Field "DT_SLAPolicy" "Active" "Boolean" $false $false $true

Write-Host "DT_Users" -ForegroundColor Yellow
Ensure-List "DT_Users" | Out-Null
Ensure-Field "DT_Users" "RowGuid" "Text" $true $true $false
Ensure-Field "DT_Users" "BusinessKey" "Text" $true $false $false
Ensure-Field "DT_Users" "Email" "Text" $true $true $true
Ensure-Field "DT_Users" "DisplayName" "Text" $false $false $false
#   domain Role: agent, lead, admin
Ensure-Field "DT_Users" "Role" "Text" $true $false $false
Ensure-Field "DT_Users" "Department" "Text" $false $false $false
Ensure-Field "DT_Users" "Active" "Boolean" $false $false $true

Write-Host "DT_AppLog" -ForegroundColor Yellow
Ensure-List "DT_AppLog" | Out-Null
Ensure-Field "DT_AppLog" "RowGuid" "Text" $true $true $false
Ensure-Field "DT_AppLog" "BusinessKey" "Text" $true $false $false
Ensure-Field "DT_AppLog" "Event" "Text" $true $false $true
Ensure-Field "DT_AppLog" "Detail" "Note" $false $false $false
Ensure-Field "DT_AppLog" "ScreenName" "Text" $false $false $false
Ensure-Field "DT_AppLog" "UserEmail" "Text" $false $false $false
Ensure-Field "DT_AppLog" "At" "DateTime" $false $false $true
Ensure-Field "DT_AppLog" "AppVersion" "Text" $false $false $false
Ensure-Field "DT_AppLog" "Success" "Boolean" $false $false $false

# --- attachments are stored as base64 text (DT_Attachments); native ones not needed --

# --- seed ------------------------------------------------------------------
Write-Host "Seed" -ForegroundColor Yellow
Ensure-Item "DT_SLAPolicy" "SLA-P1" @{ Title = "P1"; Priority = "P1"; ResponseHours = 1; ResolutionHours = 8; Active = $true }
Ensure-Item "DT_SLAPolicy" "SLA-P2" @{ Title = "P2"; Priority = "P2"; ResponseHours = 4; ResolutionHours = 24; Active = $true }
Ensure-Item "DT_SLAPolicy" "SLA-P3" @{ Title = "P3"; Priority = "P3"; ResponseHours = 8; ResolutionHours = 72; Active = $true }
Ensure-Item "DT_SLAPolicy" "SLA-P4" @{ Title = "P4"; Priority = "P4"; ResponseHours = 24; ResolutionHours = 120; Active = $true }
Ensure-Item "DT_Categories" "CAT-ACCESSPERMISSIONS" @{ Title = "Access & permissions"; Name = "Access & permissions"; Parent = ""; Description = "Access to SharePoint sites, Teams, Power BI workspaces, shared drives"; DefaultAssigneeEmail = ""; SortOrder = 1; Active = $true }
Ensure-Item "DT_Categories" "CAT-DATAREQUEST" @{ Title = "Data request"; Name = "Data request"; Parent = ""; Description = "Extracts, datasets, data corrections, new data sources"; DefaultAssigneeEmail = ""; SortOrder = 2; Active = $true }
Ensure-Item "DT_Categories" "CAT-REPORTDASHBOARD" @{ Title = "Report / Dashboard"; Name = "Report / Dashboard"; Parent = ""; Description = "New Power BI reports, changes, broken visuals, refresh failures"; DefaultAssigneeEmail = ""; SortOrder = 3; Active = $true }
Ensure-Item "DT_Categories" "CAT-POWERAPPSAUTOMATION" @{ Title = "Power Apps / Automation"; Name = "Power Apps / Automation"; Parent = ""; Description = "Apps, Power Automate flows, forms, process automation"; DefaultAssigneeEmail = ""; SortOrder = 4; Active = $true }
Ensure-Item "DT_Categories" "CAT-SOFTWARELICENSES" @{ Title = "Software & licenses"; Name = "Software & licenses"; Parent = ""; Description = "Installs, license requests, updates"; DefaultAssigneeEmail = ""; SortOrder = 5; Active = $true }
Ensure-Item "DT_Categories" "CAT-HARDWAREEQUIPMENT" @{ Title = "Hardware & equipment"; Name = "Hardware & equipment"; Parent = ""; Description = "Laptops, monitors, peripherals, mobile devices"; DefaultAssigneeEmail = ""; SortOrder = 6; Active = $true }
Ensure-Item "DT_Categories" "CAT-NETWORKVPN" @{ Title = "Network / VPN"; Name = "Network / VPN"; Parent = ""; Description = "Connectivity, VPN, Wi-Fi on site"; DefaultAssigneeEmail = ""; SortOrder = 7; Active = $true }
Ensure-Item "DT_Categories" "CAT-OTHER" @{ Title = "Other"; Name = "Other"; Parent = ""; Description = "Anything that does not fit the categories above"; DefaultAssigneeEmail = ""; SortOrder = 8; Active = $true }
Ensure-Item "DT_Categories" "CAT-REPORTDASHBOARDNEWREPORT" @{ Title = "New report"; Name = "New report"; Parent = "Report / Dashboard"; Description = ""; DefaultAssigneeEmail = ""; SortOrder = 1; Active = $true }
Ensure-Item "DT_Categories" "CAT-REPORTDASHBOARDCHANGETOEXISTINGREPORT" @{ Title = "Change to existing report"; Name = "Change to existing report"; Parent = "Report / Dashboard"; Description = ""; DefaultAssigneeEmail = ""; SortOrder = 2; Active = $true }
Ensure-Item "DT_Categories" "CAT-REPORTDASHBOARDREPORTBROKENDATANOTREFRES" @{ Title = "Report broken / data not refreshing"; Name = "Report broken / data not refreshing"; Parent = "Report / Dashboard"; Description = ""; DefaultAssigneeEmail = ""; SortOrder = 3; Active = $true }
Ensure-Item "DT_Categories" "CAT-ACCESSPERMISSIONSNEWACCESS" @{ Title = "New access"; Name = "New access"; Parent = "Access & permissions"; Description = ""; DefaultAssigneeEmail = ""; SortOrder = 1; Active = $true }
Ensure-Item "DT_Categories" "CAT-ACCESSPERMISSIONSREMOVEACCESS" @{ Title = "Remove access"; Name = "Remove access"; Parent = "Access & permissions"; Description = ""; DefaultAssigneeEmail = ""; SortOrder = 2; Active = $true }
Ensure-Item "DT_Categories" "CAT-POWERAPPSAUTOMATIONBUGINANAPPORFLOW" @{ Title = "Bug in an app or flow"; Name = "Bug in an app or flow"; Parent = "Power Apps / Automation"; Description = ""; DefaultAssigneeEmail = ""; SortOrder = 1; Active = $true }
Ensure-Item "DT_Categories" "CAT-POWERAPPSAUTOMATIONNEWAPPORFLOW" @{ Title = "New app or flow"; Name = "New app or flow"; Parent = "Power Apps / Automation"; Description = ""; DefaultAssigneeEmail = ""; SortOrder = 2; Active = $true }
$em = $AdminEmail.Trim().ToLower()
if(-not $AdminName){ $AdminName = $em }
Ensure-Item "DT_Users" ("USR-" + $em) @{ Title = $em; Email = $em; DisplayName = $AdminName; Role = "admin"; Department = "Data & Technology"; Active = $true }

Write-Host "Provisioning complete. Re-run this script any time to check for drift." -ForegroundColor Cyan
Write-Host "In Power Apps: Settings > General > Data row limit = 2000." -ForegroundColor Cyan
