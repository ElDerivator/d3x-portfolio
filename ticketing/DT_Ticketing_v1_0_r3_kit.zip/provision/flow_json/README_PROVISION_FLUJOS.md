# Provisión de SharePoint por Power Automate (DT Ticketing)

Mismo método que Colo2B: **el tenant bloquea PowerShell/PnP**, así que la provisión se hace con tus flujos de
Power Automate ("Enviar una solicitud HTTP a SharePoint", conector estándar). Los archivos tienen el **mismo
formato** que ya te funcionó en Colo2B. Generados de `sharepoint_schema.py` (8 listas, 108 columnas
y 20 filas semilla).

## Orden
| # | Archivo | Flujo | Qué hace |
|---|---|---|---|
| 1 | `01_crear_listas.json` | **crear listas** | 8 listas (BaseTemplate 100) |
| 2 | `02_crear_columnas.json` | **crear columnas** (`createfieldasxml`, `Options: 12`) | 108 columnas. Únicas e indexadas donde hace falta |
| 3 | `03_title_optional.json` | el mismo flujo genérico de HTTP que el paso 1 | `Title` **no obligatorio** en las 8 listas |
| 4 | `04_filas_semilla.json` | flujo de **filas** (el de `Colo2B_DEMO_seed.json`) | 20 filas: 4 SLA, 15 categorías y **tu usuario admin** |

Sin el paso 3, cualquier alta que no escriba `Title` falla con "Field Title is required".

**Antes del paso 4:** en `04_filas_semilla.json`, reemplaza `your.name@company.com` por **tu correo en minúsculas** (tu UPN).
Aparece 4 veces en la última fila. O regenera el archivo con
`python3 gen_flow_json.py --admin tu.correo@empresa.com --name "Tu Nombre"`. Sin esa fila nadie es admin en la app.

## Idempotencia
- Pasos 1–3: si los vuelves a correr, solo crean lo que falta (lo que ya existe falla en esa iteración y el flujo sigue).
- Paso 4: `RowGuid` es único. Si lo vuelves a correr, las filas que ya existen las **rechaza SharePoint** (salen en rojo
  en esa iteración) y no se duplican.

## Verificación
Las columnas creadas con `createfieldasxml` **no aparecen en la vista de cuadrícula**: eso es normal. Verifícalas en
*Configuración de la lista › Columnas*, donde deben salir con su nombre interno limpio, sin `_x0020_`. Revisa al menos
`DT_Tickets`: `RowGuid`, `Status`, `MailMessageId`, `HasNewMessage`.

## Lo que estos flujos NO hacen (pasos manuales)
- **Permisos (Modelo A del README):** PnP está bloqueado, así que `Lockdown-DTTicketing.ps1` no sirve en este tenant.
  Hazlo a mano en cada una de las 8 listas: *Configuración › Permisos para esta lista › Dejar de heredar permisos* →
  quitar los grupos **Miembros** y **Visitantes** del sitio → *Conceder permisos* al grupo de D&T (y a la cuenta de los
  flujos) con **Contribuir**. Si separas admins, en `DT_Users`, `DT_Categories` y `DT_SLAPolicy` deja al staff con
  **Leer** y a los admins con **Contribuir**.
- No se necesitan adjuntos nativos (las imágenes van en base64, en `DT_Attachments`) ni bibliotecas.
