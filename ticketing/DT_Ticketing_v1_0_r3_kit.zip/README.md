# Data & Technology Ticketing System — v1.0 (r3)

App canvas de Power Apps sobre **listas de SharePoint** (sin licencia premium) para que **toda la
empresa** abra tickets hacia el equipo de **Data & Technology**.

**Canal principal (r2): el correo.** Se escribe a un buzón compartido (p. ej. `dt-support@…`). El flujo F1 de
Power Automate convierte cada correo en un ticket, o en un comentario si es seguimiento de uno existente. D&T lo
clasifica y lo asigna en la app; F2 avisa por correo a la persona asignada y F3 le manda al solicitante cada
respuesta pública. **La app es solo para el equipo D&T** (`blnRequesterPortal = false`); ver "Modelo de seguridad". El equipo D&T los clasifica, asigna,
atiende y resuelve, con **SLA** de primera respuesta y de resolución. La interfaz está en **inglés**.

Es un **fork del motor de Colo2B** (`colo2b_v15_1_build`, r57, 2026-11-18): el mismo DSL en Python, los
mismos emisores pa.yaml v3.0, el mismo validador contra el esquema y las mismas reglas aprendidas en
producción. Solo el dominio es nuevo.

## Estructura

```
dt_ticketing_build/
  tools/gen/app.py               ← FUENTE DE VERDAD de la app (lo único que se edita, junto con el esquema)
  tools/gen/sharepoint_schema.py ← esquema de las 8 listas DT_* (dominios incluidos)
  tools/gen/gen_provision.py     ← genera provision/ desde el esquema
  tools/gen/gen_flows.py         ← genera flows/ (los 3 flujos de correo) desde el esquema: TODA expresión es dato aquí
  tools/gen/wdl.py               ← evaluador de expresiones de Power Automate (subconjunto usado, conservador)
  tools/gen/flow_sim.py          ← simulador de F1/F2/F3 sobre listas y correo simulados (ejecuta las expresiones reales)
  tools/gen/test_flow_sim.py     ← 34 pruebas: 30 escenarios de punta a punta del canal de correo + 4 del evaluador
  tools/gen/test_generator.py    ← 52 pruebas (app real + que el fork del motor siga atrapando bugs)
  tools/gen/{dsl,checks,control_props,emit*,build}.py, tools/powerfx_lint.py  ← motor (fork de Colo2B)
  build/Src/*.pa.yaml            ← lo que se empaca (11 archivos). NO editar a mano.
  provision/Provision-DTTicketing.ps1, provision/dt_schema.csv
  provision/Lockdown-DTTicketing.ps1   ← cierra las listas a todos menos D&T (simulacro por defecto; -Apply para aplicar)
  docs/Runbook_Puesta_en_marcha.md     ← orden de instalación + pruebas de aceptación en el tenant
  flows/F1_Intake_Email_to_Ticket.md, F2_Notify_Assignee.md, F3_Reply_to_Requester.md, flow_fields.json
```

## Gate (antes de empacar)

```bash
cd tools/gen
python3 _fastval.py                    # errores 0 · avisos 0 · linter 0
python3 -m unittest test_generator test_flow_sim   # 86/86 (app + motor 52 · flujos 34)
python3 gen_flows.py                   # flows/
python3 emit_src.py                    # build/Src (11 archivos)
python3 gen_provision.py               # provision/
```
r3: **0 / 0 / 0 · 86/86 · 11 YAML válidos · 327 controles · 14/14 mutaciones de flujos detectadas** (una 15ª, quitar `toUpper` de la key, no rompe nada porque SharePoint compara texto sin distinguir mayúsculas).

Cambio respecto a Colo2B: en `_fastval.py` el **linter ahora corre** (en un solo proceso; Colo2B lo
apagaba porque lanzaba un subproceso por fórmula). Al encenderlo salieron 182 avisos: los reales se
corrigieron y las reglas que daban falsos positivos sobre colecciones locales se acotaron (ver CHANGELOG).

## Pipeline (orden completo y pruebas de aceptación en `docs/Runbook_Puesta_en_marcha.md`)

1. **Empacar sobre un carrier** (`docs/RUNBOOK_DEV_empaque_carrier.md`). `pac canvas pack` necesita el `Src` **y** el
   `.msapr` de una app real; el `.msapr` no sale del DSL. Para esta app nueva, el operador hace una sola vez una cáscara
   en Studio con las 8 listas conectadas, la descarga y se la pasa a d3x-dev, que empaca el `Src` encima con
   `--layout SourceCode`. (r3 decía `pac canvas pack --sources build/Src`, que no funciona.)
2. **Provisionar SharePoint antes de importar:** `Provision-DTTicketing.ps1` crea las 8 listas, sus columnas e índices,
   y la semilla (4 SLA, 15 categorías, primer admin). Es idempotente y agrega las columnas nuevas a listas que ya existen.
3. **Lockdown:** `Lockdown-DTTicketing.ps1`, primero sin `-Apply` y luego con `-Apply` (ver "Modelo de seguridad").
4. **Buzón compartido y flujos:** dar a la cuenta dueña de los flujos el permiso **Send As** sobre el buzón y
   construir F1, F2 y F3 desde `flows/`, reemplazando `company.com` y `dt-support@company.com`.
5. En `App.Formulas`, ajustar `strDeskMailbox`. Importar el `.msapp`, conectar las 8 listas `DT_*` y poner
   **Settings › General › Data row limit = 2000**.
6. App Checker en Studio (ver "No verificable aquí") y luego **las pruebas de aceptación del Runbook**.

## Roles

| Rol | Quién | Puede |
|---|---|---|
| requester | **cualquiera sin fila en DT_Users** (toda la empresa) | **por correo** (Modelo A): abrir, seguir y contestar tickets. En la app solo si `blnRequesterPortal = true`: abrir, ver los suyos, responder, adjuntar, confirmar o reabrir, y cancelar si está New/Assigned |
| agent | staff D&T | lo anterior + cola, tomar/asignar, iniciar, en espera, resolver, prioridad, notas internas, dashboard |
| lead | líder D&T | lo anterior + cierre masivo de resueltos > 5 días + editar SLA |
| admin | admin de la app | lo anterior + staff, categorías/ruteo, SLA, errores |

## Ciclo por correo
1. El solicitante escribe al buzón y F1 crea el ticket **sin clasificar**: Category vacía, Medium/Medium = **P3 provisional**,
   y el SLA corre desde que llegó el correo. Le responde con el acuse `[DT-yymmdd-XXXX] asunto`.
2. D&T lo ve en la cola con 🏷 (filtro **Needs triage**) y usa **🏷 Classify** (categoría, subcategoría, impacto y urgencia;
   la fecha límite se recalcula desde la llegada). Luego lo asigna con **Assign**, y F2 le manda un correo a esa persona
   (no se manda si alguien se lo asigna a sí mismo con "Take it").
3. Toda respuesta pública del agente, y los avisos de en espera, resuelto, cancelado o reabierto, le llegan al solicitante por correo (F3).
   Las notas internas no salen nunca.
4. Si el solicitante contesta el correo, el `[key]` del asunto (o la conversación de Outlook) lo convierte en comentario
   del mismo ticket y lo marca con **✉** (filtro **New messages**). Si el ticket estaba "Waiting on requester", se reanuda
   solo. Si estaba **Resolved**, no se reabre: queda el ✉ y el agente decide. El ✉ se apaga cuando el staff responde
   en público o pulsa "Mark as read". El cierre en bloque no toca tickets con ✉.
5. Las imágenes adjuntas (hasta ~700 KB) se guardan en `DT_Attachments`. Los logos de firma se descartan. Los demás
   archivos quedan en el buzón y se listan en una nota interna.

**Protecciones de los flujos** (cada una evita un problema que ocurriría sin ella): F1 solo acepta remitentes del dominio
de la empresa, nunca el propio buzón ni respuestas automáticas o rebotes (sin esto, el acuse rebota contra un "fuera de
oficina" en bucle infinito). Además corre con concurrencia 1 y descarta un correo ya procesado (`MailMessageId`).
F2 y F3 marcan lo que ya enviaron (`NotifiedAssigneeEmail`, `MailSentAt`), así que su propia escritura no los vuelve a disparar.

## Reglas del dominio

- **Prioridad** = impacto × urgencia (`priorityFrom`, matriz ITIL; probada: monótona y completa).
- **SLA en horas calendario** por prioridad (`DT_SLAPolicy`; por defecto P1 1h/8h · P2 4h/24h · P3 8h/72h · P4 24h/120h).
  Las fechas límite se calculan al crear y se recalculan si cambia la prioridad (desde la creación + tiempo en espera).
- **On Hold pausa el reloj de resolución.** Al salir de On Hold, los minutos en espera se suman a `HoldMinutes`
  y la fecha límite se recorre esa cantidad. Si el ticket esperaba al solicitante, se **reanuda solo** cuando él contesta.
- Estado del SLA: `On track` → `At risk` (75 % consumido) → `Breached`; `Met` al resolver a tiempo; `Paused` en espera.
- **Ruteo**: si la categoría o subcategoría tiene `DefaultAssigneeEmail`, el ticket nace `Assigned` a esa persona. Si no, nace `New` y va a la cola.
- **Regla de oro** (de Colo2B): cada transición relee la fila del servidor. Si alguien cambió el estado, el asignado o la
  prioridad desde que abriste el ticket, se recarga y no se escribe a ciegas. Una fila de `DT_ChangeLog` por cada campo cambiado.
- `Resolved` espera la confirmación del solicitante: "It works — close" o "Reopen". Los leads cierran en bloque los resueltos de más de 5 días.

## Modelo de seguridad

> **Corrección respecto a r1/r2:** esas versiones recomendaban dar *Contribute* a toda la empresa sobre
> `DT_Tickets`, `DT_TicketComments` y `DT_Attachments`. Con eso **cualquier empleado podía leer todos los tickets
> de todos** (y las notas internas) abriendo la lista en SharePoint. La app filtra, pero SharePoint no.
> SharePoint no tiene permisos por fila que sirvan aquí: "solo los elementos propios" ve únicamente lo que creó
> esa persona, y los tickets los crea el flujo, así que el solicitante no los vería.

**Modelo A — recomendado y valor por defecto (`blnRequesterPortal := false`):**
- La empresa solo escribe al buzón. **Nadie fuera de D&T tiene acceso a las listas.**
- Crear un grupo de SharePoint (p. ej. "D&T Service Desk") con el equipo **y la cuenta dueña de los flujos**.
- `Lockdown-DTTicketing.ps1 -SiteUrl … -StaffGroup "D&T Service Desk" [-AdminGroup "D&T Admins"]`: primero
  **sin `-Apply`** (solo imprime el plan); revisarlo y luego repetir con `-Apply`. El script rompe la herencia
  **copiando** los permisos actuales (dueños y administradores no pierden acceso), quita los grupos Miembros y
  Visitantes del sitio de cada lista y da *Contribute* al grupo de staff. Con `-AdminGroup`, el staff queda con
  *Read* en `DT_Users`, `DT_Categories` y `DT_SLAPolicy`, y solo el grupo de admins puede editarlas.
- Compartir la app **solo** con ese grupo.
- Con esto las notas internas quedan protegidas: nadie que no sea de D&T puede leer la lista y F3 nunca las
  manda por correo. Ya no hace falta la lista aparte `DT_InternalNotes`.
- Si alguien sin acceso abre la app de todos modos, ve un aviso con el correo del buzón. La app deja de intentar
  leer su rol después de 3 intentos, para no llenar el log de errores.

**Modelo B — portal para solicitantes (`blnRequesterPortal := true`):** cualquiera abre y sigue tickets en la app.
Exige dar a toda la empresa acceso a `DT_Tickets`, `DT_TicketComments` y `DT_Attachments`, **con lo que cualquiera
puede leer todos los tickets en SharePoint**. Solo es aceptable si los tickets no tienen información confidencial.

## ⚠ Límites conocidos (decir ANTES de comprometer algo)

1. **La seguridad depende de que se aplique el Modelo A** (Lockdown + compartir la app solo con D&T). La app no
   puede proteger las listas: si se dejan abiertas, cualquiera puede leer los tickets desde SharePoint.
2. **Los flujos no se ejecutan en Power Automate desde aquí.** Lo que sí se prueba: `wdl.py` **ejecuta** cada expresión
   que se pega (30 escenarios: tickets nuevos, seguimientos, duplicados, bucles con "fuera de oficina", reanudación de
   la espera, adjuntos, F2 y F3). El evaluador es conservador: evalúa las dos ramas de `if()`, falla con nulos y aplica
   las mismas reglas de rango que la documentación de Microsoft. Las mutaciones demuestran que las pruebas detectan
   errores reales (14 de 14).
   **No probado:** los nombres reales de los campos de los conectores (`from`, `internetMessageId`, `conversationId`,
   `attachments`, `isInline`), cómo agrupa Outlook las conversaciones y el formato de salida de "Html to text".
   Esto se valida con las pruebas de aceptación del Runbook.
3. **SLA en horas calendario**, no hábiles.
4. Staff: la caché trae lo abierto + lo cerrado en los últimos 30 días (tope de 2000 filas; el pie de pantalla avisa si se llega).
5. Sin modo offline: un ticket necesita conexión para enviarse (la app lo dice; no hay cola local).
6. Adjuntos: hasta 3 imágenes por mensaje, ~700 KB cada una (base64 en 16 trozos de 60 000, el mismo patrón probado en Colo2B).
7. El texto del correo se recorta en la primera línea "From:" / "De:" / "-----Original Message-----" para no
   guardar todo el hilo citado. Es una heurística: si el cliente de correo cita de otra forma, entra el hilo completo
   (máx. 30 000 caracteres).

## No verificable aquí (revisar en Studio)

El validador revisa nombres, columnas, dominios, delegación, solapes y accesibilidad, pero **no es el compilador de
Power Fx** (lección de Colo2B r49/r50). Mirar en el App Checker de Studio en especial:
- `GroupBy(...)` + `AddColumns(..., n, CountRows(...))` del Dashboard (sintaxis de identificadores sin comillas);
- `Patch(DT_Tickets, cur, {..., OnHoldSince: Blank()})` (escribir un vacío en una fecha);
- el `If(IsBlank(ex), !IsError(Patch(...)), !IsError(Patch(...)))` de guardar staff;
- el `Switch(gblActMode, ...)` de `btnActOk` (fórmula larga: cinco transiciones completas, triage incluido);
- `drpTriSub.Default` y el `Reset` de la subcategoría al cambiar de categoría en Classify.
