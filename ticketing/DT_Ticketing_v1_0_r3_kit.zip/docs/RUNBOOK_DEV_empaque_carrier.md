# RUNBOOK DEV — empaque de DT Ticketing sobre un carrier

> Corrige el README de r3, que decía `pac canvas pack --sources build/Src --msapp …`. **Ese comando no funciona.**
> Lo confirmó d3x-dev (REPORTE_PACK_DT_r3, pac 2.14.1): el pack con `--layout SourceCode` necesita `Src/` **y** el
> `<app>.msapr` en el mismo directorio. El `.msapr` guarda las conexiones, los recursos y el manifiesto, y **no se
> puede generar desde el DSL**: sale de una app real en Studio. Es el mismo modelo de Colo2B (RUNBOOK_DEV_empaque_import_r23):
> el `Src` aporta la lógica y el carrier aporta conexiones y recursos.

## 0) Bootstrap del carrier (UNA sola vez; lo hace el operador en Studio)

DT es una app nueva y no hereda carrier. Requisito: las 8 listas ya provisionadas (`Provision-DTTicketing.ps1`).

1. make.powerapps.com → **+ Create › Blank app › Blank canvas app**
   - Name: **`Data & Technology Ticketing System`**
   - Format: **Tablet** (1366×768). Todas las coordenadas del Src asumen ese tamaño.
2. **Data › Add data › SharePoint**, en el sitio provisionado, marca las **8 listas**: `DT_Tickets`, `DT_TicketComments`,
   `DT_Attachments`, `DT_ChangeLog`, `DT_Categories`, `DT_SLAPolicy`, `DT_Users`, `DT_AppLog`.
   Los nombres tienen que coincidir exactamente: el Src las referencia así.
3. **Settings:**
   - General › **Data row limit = 2000**.
   - Updates: **Named formulas** y **User-defined functions** activados si el tenant los muestra como opción (en
     muchos ya vienen por defecto). Sin ellos, `App.Formulas` no compila.
4. No agregues pantallas ni controles: la cáscara vacía basta. **Save**.
5. **File › Save as › This computer** para descargar `DT_carrier.msapp` y pasárselo a d3x-dev.
   Ese archivo **es el carrier**: guárdalo, porque se reutiliza en todas las revisiones mientras no cambien las listas.

## 1) Empaque (d3x-dev, cada revisión)

```bash
# a) carrier -> árbol SourceCode (sale Src/ + DT_carrier.msapr)
pac canvas unpack --msapp DT_carrier.msapp --sources carrier_src --layout SourceCode
ls carrier_src            # debe tener Src/ y un *.msapr

# b) reemplazar el Src del carrier por el del handoff (los 11 .pa.yaml)
rm -f carrier_src/Src/*.pa.yaml
cp handoff/build/Src/*.pa.yaml carrier_src/Src/

# c) empacar
pac canvas pack --sources carrier_src --msapp DT_Ticketing_v1_0_r3.msapp --layout SourceCode
```

Verificación antes de entregar:
- El `Src` dentro del `.msapp` es **byte a byte** igual a `build/Src` del handoff (las rutas internas usan `\`).
- Hay 11 `.pa.yaml` y 327 controles.
- El `.msapr` del pack es el del carrier DT, **nunca uno prestado** de otra app (un `.msapr` de Colo2B arrastra las
  conexiones `OD_*`).

## 2) Import (operador)

Abrir el `.msapp` en Studio. Las conexiones vienen del carrier, así que **no debería pedir reconectar**. Si las pide,
enlaza las 8 listas `DT_*` del mismo sitio. Después: App Checker (ver "No verificable aquí" en el README), **Save** y
**Publish**.

Opcional: después del primer import bueno, **exporta esa app** y úsala como carrier nuevo. Así ya viene validada en Studio.

## 3) Cuándo hay que rehacer el carrier

Solo si cambia el **conjunto de listas**, ya sea una lista nueva o un nombre distinto. Si solo se agregan columnas,
el carrier sirve igual: cuando Studio lo pida, basta con **Refresh** de la fuente.
