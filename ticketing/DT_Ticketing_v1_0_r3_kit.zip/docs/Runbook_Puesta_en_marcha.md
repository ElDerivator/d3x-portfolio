# Runbook — puesta en marcha del Data & Technology Ticketing System (v1.0 r3)

Orden obligatorio: cada paso depende del anterior. Marca cada casilla con la evidencia (captura, ID de ejecución
del flujo o fila de la lista) y no con "creo que sí".

## A · Preparación (una sola vez)

- [ ] **A1 Sitio de SharePoint** dedicado o existente. Anota la URL.
- [ ] **A2 Buzón compartido** (p. ej. `dt-support@<empresa>`), creado en Exchange.
- [ ] **A3 Cuenta dueña de los flujos.** Lo ideal es una cuenta de servicio con licencia, no una persona: si esa persona
      se va, los flujos se apagan. Necesita el permiso **Send As** sobre el buzón (Exchange admin › buzón ›
      Delegación) y acceso a las listas (paso A5).
- [ ] **A4 Provisionar:** `.\Provision-DTTicketing.ps1 -SiteUrl <url> -AdminEmail <tu correo>`.
      Evidencia: 8 listas, la de categorías con 15 filas, la de SLA con 4 y la de usuarios con 1.
- [ ] **A5 Grupo de SharePoint** "D&T Service Desk" con el equipo y la cuenta de A3. Si quieres separar admins,
      crea también un grupo "D&T Admins".
- [ ] **A6 Lockdown, simulacro:** `.\Lockdown-DTTicketing.ps1 -SiteUrl <url> -StaffGroup "D&T Service Desk"`.
      Lee el plan que imprime.
- [ ] **A7 Lockdown, aplicar:** el mismo comando con `-Apply`. Evidencia: en *Configuración de la lista › Permisos*
      de `DT_Tickets` aparece "D&T Service Desk = Contribuir" y ya no están los Miembros ni los Visitantes del sitio.
- [ ] **A8 Prueba negativa:** una persona que **no** sea de D&T abre la URL de `DT_Tickets` y obtiene "acceso denegado".

## B · Flujos (construir desde `flows/`, solo con conectores estándar)

- [ ] **B1 F1** según `F1_Intake_Email_to_Ticket.md`. En *Configuración* del disparador: concurrencia 1 y las
      4 condiciones. Reemplaza `company.com` y `dt-support@company.com`.
- [ ] **B2 Verifica los nombres de los campos del disparador** (lo único que el simulador no puede probar): manda un
      correo de prueba y, en el historial de la ejecución, abre las *salidas* del disparador. Confirma que existen
      `from`, `subject`, `body`, `internetMessageId`, `conversationId`, `receivedDateTime` y `attachments`
      (con `name`, `contentType`, `contentBytes`, `size` e `isInline`). Si alguno se llama distinto, corrígelo en
      `tools/gen/gen_flows.py`, vuelve a correr las pruebas y regenera los flujos. No lo cambies solo en el diseñador.
- [ ] **B3 F2** según `F2_Notify_Assignee.md`.
- [ ] **B4 F3** según `F3_Reply_to_Requester.md`.
- [ ] **B5** Activa las alertas de fallo de los 3 flujos (*Editar › Configuración › alertas a los dueños*).

## C · App

- [ ] **C1** En `App.Formulas`, cambia `strDeskMailbox` al buzón real y deja `blnRequesterPortal := false`.
- [ ] **C0 Carrier** (una sola vez, después de A4): cáscara en Studio con las 8 listas conectadas, descargada como
      `DT_carrier.msapp` y entregada a d3x-dev. Ver `RUNBOOK_DEV_empaque_carrier.md` §0.
- [ ] **C2** d3x-dev empaca sobre el carrier. Importa ese `.msapp`; ya trae las conexiones. Si las pide, enlaza las 8 listas.
      Confirma **Data row limit = 2000**.
- [ ] **C3 App Checker:** 0 errores. Revisa sobre todo las fórmulas de "No verificable aquí" en el README.
- [ ] **C4** Comparte la app **solo** con "D&T Service Desk".
- [ ] **C5** Da de alta al equipo en *Administration* con su rol (agent, lead o admin).

## D · Pruebas de aceptación (cada una es la versión en el tenant de un escenario de `test_flow_sim.py`)

Usa 2 cuentas: **S** (solicitante, fuera de D&T) y **G** (agente). La "evidencia" es lo que hay que ver.

| # | Acción | Evidencia esperada | Escenario del simulador |
|---|---|---|---|
| D1 | S escribe al buzón "RE: FW: No abre el reporte de ventas" con una captura pegada en el cuerpo | En `DT_Tickets` aparece una fila nueva con Status New, P3, Category vacía, Source Email y título **sin** "RE: FW:". S recibe el acuse `[DT-yymmdd-XXXX] …`. La captura aparece en la pestaña Attachments del ticket | `test_new_mail_creates_an_unclassified_ticket_and_acks`, `test_image_round_trips…` |
| D2 | S tiene activo el "fuera de oficina" y repite D1 | Un **solo** ticket. La respuesta automática aparece en el historial de F1 como *no disparada* (condición falsa) | `test_out_of_office_on_the_ack_does_not_loop` |
| D3 | Alguien con cuenta externa (gmail) escribe al buzón | No se crea ningún ticket | `test_external_robot_and_self_senders_are_filtered` |
| D4 | S contesta el acuse ("aquí más info", conservando el hilo citado) | No hay ticket nuevo. En el ticket aparece un comentario "✉ e-mail" **solo con el texto nuevo**, y el ticket muestra ✉ en la cola | `test_reply_with_key…`, `test_quoted_thread_is_cut` |
| D5 | G clasifica el ticket (🏷 Classify: categoría y Urgency=High) | P2, fechas límite recalculadas desde la llegada del correo, 2 filas en History | (app) ACT_TRIAGE |
| D6 | Un lead asigna el ticket a G | G recibe "Assigned to you". Si se edita cualquier otra cosa del ticket, **no** le llega un segundo correo | `test_assignment_mails_the_assignee_once` |
| D7 | G pulsa "Take it" en otro ticket | No se manda correo | `test_taking_it_yourself_sends_nothing_but_marks` |
| D8 | G responde en público con `<b>` y `&` en el texto | S recibe el texto literal (no en negritas), con `[key]` en el asunto. El ✉ desaparece | `test_public_reply_reaches_the_requester_escaped…` |
| D9 | G escribe una nota interna | S **no** recibe nada | `test_internal_notes_and_own_messages_are_not_mailed` |
| D10 | G pone el ticket en espera "Waiting on requester" y S contesta 10 min después | S recibió el aviso de espera. Al contestar, el ticket vuelve a In Progress, HoldMinutes ≈ 10 y la fecha límite se recorre lo mismo | `test_requester_answer_resumes…`, `test_system_notice_is_mailed` |
| D11 | G resuelve y S contesta "¡gracias!" | El ticket **sigue Resolved** y tiene ✉. El cierre en bloque no lo cierra mientras tenga ✉ | `test_a_resolved_ticket_is_not_reopened_by_a_thanks` |
| D12 | Un lead cierra el ticket y S vuelve a contestar ese hilo | Se crea un ticket **nuevo** con la descripción "Follow-up of DT-… (closed)." | `test_key_of_a_closed_ticket_opens_a_new_one…` |
| D13 | S manda un PDF y una imagen de más de 1 MB | No se guardan como adjuntos. Una nota interna los lista y le dice a D&T que los busque en el buzón | `test_too_big_and_non_images_are_listed…` |
| D14 | S abre la app | Ve el aviso "This app is used by the D&T team… e-mail …" y no hay errores repetidos en Admin › errores | (app) portal off |
| D15 | Reenvía a mano al buzón un correo ya procesado | El mismo `internetMessageId` no crea un segundo ticket | `test_duplicate_delivery_creates_one_ticket` |

Si una prueba falla: anota la ejecución del flujo (ID), la fila y el paso, y no "parches" en el diseñador. Corrige en
`gen_flows.py`, agrega el caso al simulador, comprueba que falla, arregla y regenera.

## E · Operación diaria

- Cola › filtro **Needs triage** (correos sin clasificar) y **New messages** (✉ sin respuesta): revisarlos al menos 2 veces al día.
- Admin › *Recent errors*: incluye `flow-intake-failed` (F1 cayó al Catch). Cada uno es un correo que **no** se convirtió
  en ticket: búscalo en el buzón y ábrelo a mano con "New ticket" en nombre del solicitante, lo que también le avisa por correo.
- Un lead cierra en bloque los resueltos de más de 5 días que no tengan ✉.
